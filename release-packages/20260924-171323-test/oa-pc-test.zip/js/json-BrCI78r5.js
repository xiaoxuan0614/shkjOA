import{B as e,D as t,Et as n,F as r,M as i,N as a,et as o,i as s,it as c,mt as l,yt as u}from"./emoji-mart-vue-fast-hGh2MZwu.js";import{t as d}from"./radio-jxhqywk_.js";import{t as f}from"./modal-CVRIxnMW.js";import{t as p}from"./Page-B35Yr3ag.js";import{m}from"./index-vCfNb80s.js";import{t as h}from"./CodeEditor-CCccUA1l.js";e(),u();var g=`{"name":"BeJson","url":"http://www.xxx.com","page":88,"isNonProfit":true,"address":{"street":"科技园路.","city":"江苏苏州","country":"中国"},"links":[{"name":"Google","url":"http://www.xxx.com"},{"name":"Baidu","url":"http://www.xxx.com"},{"name":"SoSo","url":"http://www.xxx.com"}]}`,_=`
      (() => {
        var htmlRoot = document.getElementById('htmlRoot');
        var theme = window.localStorage.getItem('__APP__DARK__MODE__');
        if (htmlRoot && theme) {
          htmlRoot.setAttribute('data-theme', theme);
          theme = htmlRoot = null;
        }
      })();
  `,v=`
     <!DOCTYPE html>
<html lang="en" id="htmlRoot">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="renderer" content="webkit" />
    <meta
      name="viewport"
      content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=0"
    />
    <title><%= title %></title>
    <link rel="icon" href="/favicon.ico" />
  </head>
  <body>
    <div id="app">
    </div>
  </body>
</html>
  `,y=r({components:{CodeEditor:h,PageWrapper:p,RadioButton:d.Button,RadioGroup:d.Group,ASpace:m},setup(){let e=n(`application/json`),t=n(g);function r(e){let n=e.target.value;if(n===`application/json`){t.value=g;return}if(n===`htmlmixed`){t.value=v;return}if(n===`javascript`){t.value=_;return}}function i(){f.info({title:`编辑器当前值`,content:t.value})}return{value:t,modeValue:e,handleModeChange:r,showData:i}}});e();function b(e,n,r,s,u,d){let f=c(`a-button`),p=c(`RadioButton`),h=c(`RadioGroup`),g=m,_=c(`CodeEditor`),v=c(`PageWrapper`);return o(),t(v,{title:`代码编辑器组件示例`,contentFullHeight:``,fixedHeight:``,contentBackground:``},{extra:l(()=>[a(g,{size:`middle`},{default:l(()=>[a(f,{onClick:e.showData,type:`primary`},{default:l(()=>[...n[2]||(n[2]=[i(`获取数据`,-1)])]),_:1},8,[`onClick`]),a(h,{"button-style":`solid`,value:e.modeValue,"onUpdate:value":n[0]||(n[0]=t=>e.modeValue=t),onChange:e.handleModeChange},{default:l(()=>[a(p,{value:`application/json`},{default:l(()=>[...n[3]||(n[3]=[i(` json数据 `,-1)])]),_:1}),a(p,{value:`htmlmixed`},{default:l(()=>[...n[4]||(n[4]=[i(` html代码 `,-1)])]),_:1}),a(p,{value:`javascript`},{default:l(()=>[...n[5]||(n[5]=[i(` javascript代码 `,-1)])]),_:1})]),_:1},8,[`value`,`onChange`])]),_:1})]),default:l(()=>[a(_,{value:e.value,"onUpdate:value":n[1]||(n[1]=t=>e.value=t),mode:e.modeValue},null,8,[`value`,`mode`])]),_:1})}var x=s(y,[[`render`,b]]);export{x as default};