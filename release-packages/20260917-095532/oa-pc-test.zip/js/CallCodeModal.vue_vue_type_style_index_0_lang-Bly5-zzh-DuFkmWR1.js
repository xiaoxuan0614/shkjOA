import{$ as e,B as t,D as n,E as r,F as i,M as a,N as o,O as s,_t as c,ft as l,jt as u,k as d,rt as f,wt as p}from"./emoji-mart-vue-fast-DyK5_yEY.js";import{a as m}from"./useConfigInject-Cuvs14JQ.js";import{n as h,t as g}from"./tabs-CvEPFtc5.js";import{t as _}from"./TextArea-eIWU2OeO.js";import{n as v}from"./setting-CHwsSsjF.js";import{i as y}from"./auth-B2Anm32l.js";import{t as b}from"./useMessage-DYwXdvGg.js";import{t as x}from"./useCopyToClipboard-DjEJCxqJ.js";import{t as S}from"./Modal-Cw5PIITt.js";import{n as C}from"./useModal-w8LvbKM6.js";t(),c();var w=(e,t,n)=>new Promise((r,i)=>{var a=e=>{try{s(n.next(e))}catch(e){i(e)}},o=e=>{try{s(n.throw(e))}catch(e){i(e)}},s=e=>e.done?r(e.value):Promise.resolve(e.value).then(a,o);s((n=n.apply(e,t)).next())}),T={key:0,class:`call-code-modal-content`},E={style:{display:`flex`,"justify-content":`flex-end`,"margin-top":`8px`}},D=i({__name:`CallCodeModal`,setup(t){let{createMessage:i}=b(),c=p(`curl`),D=p(``),O=p(``),k=p(``),{domainUrl:A}=v(),[j,{closeModal:M,getOpen:N}]=C(e=>w(null,null,function*(){k.value=``;let{record:t}=e;if(!t){k.value=`[错误] 没有传入流程数据！`;return}let n=y(),{id:r,metadata:i}=t;if(!i){k.value=`[错误] 没有找到入参参数！`;return}P(r,i,n),F(r,i)}));function P(e,t,n){let r=`"inputParams": {`,i=[];if(Array.isArray(t)&&t.length>0)for(let{field:e}of t)I(e)||i.push(`        "${e}": ""`);i.length>0?(r+=`
`,r+=i.join(`,
`),r+=`
`,r+=`      },`):r+=`},`,D.value=`
curl --request POST \\
  --url ${A}/airag/flow/run \\
  --header 'Accept: */*' \\
  --header 'Accept-Encoding: gzip, deflate, br' \\
  --header 'Connection: keep-alive' \\
  --header 'Content-Type: application/json' \\
  --header 'Cookie: JSESSIONID=442C48D3D1D0B2878A597AB6EBF2A07E' \\
  --header 'User-Agent: PostmanRuntime-ApipostRuntime/1.1.0' \\
  --header 'X-Access-Token: ${n}' \\
  --data '{
      "flowId": "${e}",
      ${r}
      "responseMode":"blocking"
    }'
    `.trim()}function F(e,t){let n=[];if(Array.isArray(t)&&t.length>0)for(let{field:e}of t)I(e)||n.push(`inputs.put("${e}", "");`);O.value=`
@Autowired
ISysBaseAPI sysBaseAPI;
// ..... 省略代码
AiragFlowDTO params = new AiragFlowDTO();
params.setFlowId("${e}");
Map<String, Object> inputs = new HashMap<>();
${n.join(`
`)}
params.setInputParams(inputs);
Result<Object> o = (Result<Object>) sysBaseAPI.runAiragFlow(params);
`.trim()}function I(e){return[`history`].includes(e)}function L(){return w(this,null,function*(){let e=c.value===`curl`?D.value:O.value;x(e)?i.success(`复制成功`):prompt(`复制失败，请手动复制`,e)})}function R(){M()}return(t,i)=>{let p=m,v=_,y=h,b=g,x=f(`a-button`);return e(),n(u(S),{onRegister:u(j),width:`600px`,header:null,footer:null,canFullscreen:!1,wrapClassName:`call-code-modal`,onOk:L,onClose:R},{default:l(()=>[u(N)?(e(),d(`div`,T,[i[4]||(i[4]=r(`p`,{class:`call-code-modal-title`},`查看调用代码`,-1)),k.value?(e(),n(p,{key:0,description:k.value},null,8,[`description`])):(e(),n(b,{key:1,activeKey:c.value,"onUpdate:activeKey":i[2]||(i[2]=e=>c.value=e),animated:``},{default:l(()=>[o(y,{key:`curl`,tab:`curl`},{default:l(()=>[o(v,{value:D.value,"onUpdate:value":i[0]||(i[0]=e=>D.value=e),rows:20,style:{resize:`none`}},null,8,[`value`])]),_:1}),o(y,{key:`java`,tab:`java`},{default:l(()=>[o(v,{value:O.value,"onUpdate:value":i[1]||(i[1]=e=>O.value=e),rows:20,style:{resize:`none`}},null,8,[`value`])]),_:1})]),_:1},8,[`activeKey`])),r(`div`,E,[o(x,{type:`primary`,preIcon:`ant-design:copy-outlined`,onClick:L},{default:l(()=>[...i[3]||(i[3]=[a(`复制`,-1)])]),_:1})])])):s(``,!0)]),_:1},8,[`onRegister`])}}});export{D as t};