import{B as e,D as t,E as n,Et as r,F as i,M as a,N as o,Nt as s,O as c,et as l,it as u,k as d,mt as f,yt as p}from"./emoji-mart-vue-fast-hGh2MZwu.js";import{a as m}from"./useConfigInject-Bx-RUe0H.js";import{n as h,t as g}from"./tabs-DGc6TnbW.js";import{t as _}from"./TextArea-JzGTaMq3.js";import{n as v}from"./setting-CHwsSsjF.js";import{i as y}from"./auth-Dwpq_RBl.js";import{t as b}from"./useMessage-BNca6i8V.js";import{t as x}from"./useCopyToClipboard-BJbQdLGR.js";import{t as S}from"./Modal-DPLERnO1.js";import{n as C}from"./useModal-BPthxDpw.js";e(),p();var w=(e,t,n)=>new Promise((r,i)=>{var a=e=>{try{s(n.next(e))}catch(e){i(e)}},o=e=>{try{s(n.throw(e))}catch(e){i(e)}},s=e=>e.done?r(e.value):Promise.resolve(e.value).then(a,o);s((n=n.apply(e,t)).next())}),T={key:0,class:`call-code-modal-content`},E={style:{display:`flex`,"justify-content":`flex-end`,"margin-top":`8px`}},D=i({__name:`CallCodeModal`,setup(e){let{createMessage:i}=b(),p=r(`curl`),D=r(``),O=r(``),k=r(``),{domainUrl:A}=v(),[j,{closeModal:M,getOpen:N}]=C(e=>w(null,null,function*(){k.value=``;let{record:t}=e;if(!t){k.value=`[错误] 没有传入流程数据！`;return}let n=y(),{id:r,metadata:i}=t;if(!i){k.value=`[错误] 没有找到入参参数！`;return}P(r,i,n),F(r,i)}));function P(e,t,n){let r=`"inputParams": {`,i=[];if(Array.isArray(t)&&t.length>0)for(let{field:e}of t)I(e)||i.push(`        "${e}": ""`);i.length>0?(r+=`
`,r+=i.join(`,
`),r+=`
`,r+=`      },`):r+=`},`,D.value=`
curl --request POST \\
  --url ${A}/airag/flow/run \\
  --header 'Accept: */*' \\
  --header 'Accept-Encoding: gzip, deflate, br' \\
  --header 'Connection: keep-alive' \\
  --header 'Content-Type: application/json' \\
  --header 'Cookie: JSESSIONID=442C48D3D1D0B2878A597AB6EBF2A07E' \\
  --header 'User-Agent: PostmanRuntime-ApipostRuntime/1.1.0' \\
  --header 'X-Access-Token: ${n}' \\
  --data '{
      "flowId": "${e}",
      ${r}
      "responseMode":"blocking"
    }'
    `.trim()}function F(e,t){let n=[];if(Array.isArray(t)&&t.length>0)for(let{field:e}of t)I(e)||n.push(`inputs.put("${e}", "");`);O.value=`
@Autowired
ISysBaseAPI sysBaseAPI;
// ..... 省略代码
AiragFlowDTO params = new AiragFlowDTO();
params.setFlowId("${e}");
Map<String, Object> inputs = new HashMap<>();
${n.join(`
`)}
params.setInputParams(inputs);
Result<Object> o = (Result<Object>) sysBaseAPI.runAiragFlow(params);
`.trim()}function I(e){return[`history`].includes(e)}function L(){return w(this,null,function*(){let e=p.value===`curl`?D.value:O.value;x(e)?i.success(`复制成功`):prompt(`复制失败，请手动复制`,e)})}function R(){M()}return(e,r)=>{let i=m,v=_,y=h,b=g,x=u(`a-button`);return l(),t(s(S),{onRegister:s(j),width:`600px`,header:null,footer:null,canFullscreen:!1,wrapClassName:`call-code-modal`,onOk:L,onClose:R},{default:f(()=>[s(N)?(l(),d(`div`,T,[r[4]||(r[4]=n(`p`,{class:`call-code-modal-title`},`查看调用代码`,-1)),k.value?(l(),t(i,{key:0,description:k.value},null,8,[`description`])):(l(),t(b,{key:1,activeKey:p.value,"onUpdate:activeKey":r[2]||(r[2]=e=>p.value=e),animated:``},{default:f(()=>[o(y,{key:`curl`,tab:`curl`},{default:f(()=>[o(v,{value:D.value,"onUpdate:value":r[0]||(r[0]=e=>D.value=e),rows:20,style:{resize:`none`}},null,8,[`value`])]),_:1}),o(y,{key:`java`,tab:`java`},{default:f(()=>[o(v,{value:O.value,"onUpdate:value":r[1]||(r[1]=e=>O.value=e),rows:20,style:{resize:`none`}},null,8,[`value`])]),_:1})]),_:1},8,[`activeKey`])),n(`div`,E,[o(x,{type:`primary`,preIcon:`ant-design:copy-outlined`,onClick:L},{default:f(()=>[...r[3]||(r[3]=[a(`复制`,-1)])]),_:1})])])):c(``,!0)]),_:1},8,[`onRegister`])}}});export{D as t};