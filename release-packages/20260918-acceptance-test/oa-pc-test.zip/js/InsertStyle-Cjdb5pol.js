import{B as e,F as t,I as n,R as r,V as i,W as a,_t as o,wt as s}from"./emoji-mart-vue-fast-DyK5_yEY.js";import{n as c}from"./index.esm-BdEVdcnk.js";e(),o();var l=Symbol(`iconContext`),u=function(){return i(l,{prefixCls:s(`anticon`),rootClassName:s(``),csp:s()})};function d(){return!!(typeof window<`u`&&window.document&&window.document.createElement)}function f(e,t){return e&&e.contains?e.contains(t):!1}var p=`data-vc-order`,m=`vc-icon-key`,h=new Map;function g(){var e=(arguments.length>0&&arguments[0]!==void 0?arguments[0]:{}).mark;return e?e.startsWith(`data-`)?e:`data-${e}`:m}function _(e){return e.attachTo?e.attachTo:document.querySelector(`head`)||document.body}function v(e){return e===`queue`?`prependQueue`:e?`prepend`:`append`}function y(e){return Array.from((h.get(e)||e).children).filter(function(e){return e.tagName===`STYLE`})}function b(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};if(!d())return null;var n=t.csp,r=t.prepend,i=document.createElement(`style`);i.setAttribute(p,v(r)),n&&n.nonce&&(i.nonce=n.nonce),i.innerHTML=e;var a=_(t),o=a.firstChild;if(r){if(r===`queue`){var s=y(a).filter(function(e){return[`prepend`,`prependQueue`].includes(e.getAttribute(p))});if(s.length)return a.insertBefore(i,s[s.length-1].nextSibling),i}a.insertBefore(i,o)}else a.appendChild(i);return i}function x(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};return y(_(t)).find(function(n){return n.getAttribute(g(t))===e})}function S(e,t){var n=h.get(e);if(!n||!f(document,n)){var r=b(``,t),i=r.parentNode;h.set(e,i),e.removeChild(r)}}function C(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};S(_(n),n);var r=x(t,n);if(r)return n.csp&&n.csp.nonce&&r.nonce!==n.csp.nonce&&(r.nonce=n.csp.nonce),r.innerHTML!==e&&(r.innerHTML=e),r;var i=b(e,n);return i.setAttribute(g(n),t),i}e();function w(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:Object(arguments[t]),r=Object.keys(n);typeof Object.getOwnPropertySymbols==`function`&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){T(e,t,n[t])})}return e}function T(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function E(e,t){`${t}`}function D(e){return typeof e==`object`&&typeof e.name==`string`&&typeof e.theme==`string`&&(typeof e.icon==`object`||typeof e.icon==`function`)}function O(e,t,n){return n?r(e.tag,w({key:t},n,e.attrs),(e.children||[]).map(function(n,r){return O(n,`${t}-${e.tag}-${r}`)})):r(e.tag,w({key:t},e.attrs),(e.children||[]).map(function(n,r){return O(n,`${t}-${e.tag}-${r}`)}))}function k(e){return c(e)[0]}function A(e){return e?Array.isArray(e)?e:[e]:[]}var j={width:`1em`,height:`1em`,fill:`currentColor`,"aria-hidden":`true`,focusable:`false`},M=`
.anticon {
  display: inline-block;
  color: inherit;
  font-style: normal;
  line-height: 0;
  text-align: center;
  text-transform: none;
  vertical-align: -0.125em;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.anticon > * {
  line-height: 1;
}

.anticon svg {
  display: inline-block;
}

.anticon::before {
  display: none;
}

.anticon .anticon-icon {
  display: block;
}

.anticon[tabindex] {
  cursor: pointer;
}

.anticon-spin::before,
.anticon-spin {
  display: inline-block;
  -webkit-animation: loadingCircle 1s infinite linear;
  animation: loadingCircle 1s infinite linear;
}

@-webkit-keyframes loadingCircle {
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}

@keyframes loadingCircle {
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
`;function N(e){return e&&e.getRootNode&&e.getRootNode()}function P(e){return d()?N(e)instanceof ShadowRoot:!1}function F(e){return P(e)?N(e):null}var I=function(){var e=u(),t=e.prefixCls,r=e.csp,i=n(),o=M;t&&(o=o.replace(/anticon/g,t.value)),a(function(){if(d()){var e=i.vnode.el,t=F(e);C(o,`@ant-design-vue-icons`,{prepend:!0,csp:r.value,attachTo:t})}})};e();var L=t({name:`InsertStyles`,setup:function(){return I(),function(){return null}}});export{A as a,u as c,D as i,O as n,j as o,k as r,E as s,L as t};