import{$ as e,B as t,D as n,F as r,M as i,N as a,_t as o,ft as s,i as c,rt as l,wt as u}from"./emoji-mart-vue-fast-DyK5_yEY.js";import{t as d}from"./radio-Bzd9174V.js";import{t as f}from"./modal-Z10gAUlN.js";import{t as p}from"./Page-Go4E-j5k.js";import{m}from"./index-DuT_VyF_.js";import{t as h}from"./CodeEditor-DfzVQMEB.js";t(),o();var g=`{"name":"BeJson","url":"http://www.xxx.com","page":88,"isNonProfit":true,"address":{"street":"科技园路.","city":"江苏苏州","country":"中国"},"links":[{"name":"Google","url":"http://www.xxx.com"},{"name":"Baidu","url":"http://www.xxx.com"},{"name":"SoSo","url":"http://www.xxx.com"}]}`,_=`
      (() => {
        var htmlRoot = document.getElementById('htmlRoot');
        var theme = window.localStorage.getItem('__APP__DARK__MODE__');
        if (htmlRoot && theme) {
          htmlRoot.setAttribute('data-theme', theme);
          theme = htmlRoot = null;
        }
      })();
  `,v=`
     <!DOCTYPE html>
<html lang="en" id="htmlRoot">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="renderer" content="webkit" />
    <meta
      name="viewport"
      content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=0"
    />
    <title><%= title %></title>
    <link rel="icon" href="/favicon.ico" />
  </head>
  <body>
    <div id="app">
    </div>
  </body>
</html>
  `,y=r({components:{CodeEditor:h,PageWrapper:p,RadioButton:d.Button,RadioGroup:d.Group,ASpace:m},setup(){let e=u(`application/json`),t=u(g);function n(e){let n=e.target.value;if(n===`application/json`){t.value=g;return}if(n===`htmlmixed`){t.value=v;return}if(n===`javascript`){t.value=_;return}}function r(){f.info({title:`编辑器当前值`,content:t.value})}return{value:t,modeValue:e,handleModeChange:n,showData:r}}});t();function b(t,r,o,c,u,d){let f=l(`a-button`),p=l(`RadioButton`),h=l(`RadioGroup`),g=m,_=l(`CodeEditor`),v=l(`PageWrapper`);return e(),n(v,{title:`代码编辑器组件示例`,contentFullHeight:``,fixedHeight:``,contentBackground:``},{extra:s(()=>[a(g,{size:`middle`},{default:s(()=>[a(f,{onClick:t.showData,type:`primary`},{default:s(()=>[...r[2]||(r[2]=[i(`获取数据`,-1)])]),_:1},8,[`onClick`]),a(h,{"button-style":`solid`,value:t.modeValue,"onUpdate:value":r[0]||(r[0]=e=>t.modeValue=e),onChange:t.handleModeChange},{default:s(()=>[a(p,{value:`application/json`},{default:s(()=>[...r[3]||(r[3]=[i(` json数据 `,-1)])]),_:1}),a(p,{value:`htmlmixed`},{default:s(()=>[...r[4]||(r[4]=[i(` html代码 `,-1)])]),_:1}),a(p,{value:`javascript`},{default:s(()=>[...r[5]||(r[5]=[i(` javascript代码 `,-1)])]),_:1})]),_:1},8,[`value`,`onChange`])]),_:1})]),default:s(()=>[a(_,{value:t.value,"onUpdate:value":r[1]||(r[1]=e=>t.value=e),mode:t.modeValue},null,8,[`value`,`mode`])]),_:1})}var x=c(y,[[`render`,b]]);export{x as default};